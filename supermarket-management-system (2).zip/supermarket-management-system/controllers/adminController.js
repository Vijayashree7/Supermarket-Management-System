// controllers/adminController.js
const path = require('path');
const db = require('../db');

exports.login = (req, res) => {
  const { username, password } = req.body;

  const sql = 'SELECT * FROM admins WHERE admin_name = ? AND password = ?';
  db.query(sql, [username, password], (err, results) => {
    if (err) {
      console.error('Login error:', err);
      return res.status(500).send('Internal Server Error');
    }

    if (results.length > 0) {
      // Successful login
      res.redirect('/admin/dashboard');
    } else {
      // Failed login: redirect to login with error query param
      res.redirect('/admin/login?error=1');
    }
  });
};

exports.dashboard = (req, res) => {
  res.sendFile(path.join(__dirname, '../views/dashboard.html'));
};

exports.viewSection = (req, res) => {
  res.sendFile(path.join(__dirname, '../views/viewSection.html'));
};

exports.manageSection = (req, res) => {
  res.sendFile(path.join(__dirname, '../views/manageSection.html'));
};

exports.viewBranch = (req, res) => {
  db.query('SELECT * FROM branches', (err, results) => {
    if (err) return res.status(500).send('DB Error');
    res.render('view-table', { title: 'Branch List', data: results });
  });
};

exports.viewEmployee = (req, res) => {
  db.query('SELECT * FROM employees', (err, results) => {
    if (err) return res.status(500).send('DB Error');
    res.render('view-table', { title: 'Employee List', data: results });
  });
};

exports.viewAdmin = (req, res) => {
  const sql = 'SELECT admin_id, admin_name, email, branch_id FROM admins';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching admin data:', err);
      return res.status(500).send('Error fetching admin data');
    }
    res.render('view-table', { title: 'Admin List', data: results });
  });
};

exports.viewCustomers = (req, res) => {
  const customerQuery = `
    SELECT c.customer_id, c.customer_name, c.purchase_date,
      GROUP_CONCAT(CONCAT(p.product_name, '(', pu.quantity, ')') SEPARATOR ', ') AS products_purchased,
      SUM(p.price * pu.quantity) AS total_amount
    FROM customers c
    JOIN purchases pu ON c.customer_id = pu.customer_id
    JOIN products p ON pu.product_id = p.product_id
    GROUP BY c.customer_id, c.customer_name, c.purchase_date
  `;

  db.query(customerQuery, (err, results) => {
    if (err) {
      console.error('Query Error:', err);
      return res.status(500).send('DB Error');
    }

    console.log('Customer Query Results:', results); // 🔍 DEBUG

    res.render('view-table', {
      title: 'Customer List',
      data: results
    });
  });
};



exports.viewProducts = (req, res) => {
  db.query('SELECT * FROM products', (err, results) => {
    if (err) return res.status(500).send('DB Error');
    res.render('view-table', { title: 'Product List', data: results });
  });
};

exports.updateProductImage = (req, res) => {
  const productId = req.body.product_id;
  const imagePath = req.file.filename;

  db.query(
    'UPDATE products SET image_url = ? WHERE product_id = ?',
    [imagePath, productId],
    (err) => {
      if (err) return res.status(500).send('DB Error');
      res.redirect('/admin/view-products');
    }
  );
};


// --- 1. ADD PRODUCT ---
exports.addProductForm = (req, res) => {
  const successMessage = req.query.success || '';
  res.send(`
    <html>
    <head>
      <title>Add Product</title>
      <style>
        body {
          background: url('/images/sms2.jpg') no-repeat center center fixed;
          background-size: cover;
          font-family: Arial, sans-serif;
          color: white;
        }
        .container {
          width: 400px;
          margin: 80px auto;
          padding: 30px;
          background-color: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.3);
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(255, 255, 255, 0.938);
        }
        h2 {
          text-align: center;
          margin-top: 0;
          margin-bottom: 20px;
        }
        label {
          display: block;
          margin-top: 10px;
          margin-bottom: 5px;
        }
        input, select {
          width: 100%;
          padding: 8px;
          background: #222;
          color: white;
          border: 1px solid #444;
          border-radius: 4px;
        }
        button {
          width: 100%;
          margin-top: 15px;
          padding: 10px;
          background-color: #007BFF;
          border: none;
          color: white;
          font-weight: bold;
          border-radius: 5px;
          cursor: pointer;
        }
        button:hover {
          background-color: #0056b3;
        }
        .top-right {
          position: absolute;
          top: 20px;
          right: 30px;
        }
        .top-right button {
          background-color: #cc0000;
        }
        .top-right button:hover {
          background-color: #ff0000;
        }
        p {
          text-align: center;
          margin-top: 15px;
        }
      </style>
    </head>
    <body>
      <div class="top-right">
        <button onclick="location.href='/admin/manage-section'">Back</button>
      </div>
      <div class="container">
        <h2>Add Product</h2>
        <form action="/admin/add-product" method="POST" enctype="multipart/form-data">
          <label>Product Name:</label>
          <input type="text" name="product_name" required>

          <label>Quantity:</label>
          <input type="number" name="quantity" required>

          <label>Re-stock Level:</label>
          <input type="number" name="stock" required>

          <label>Price (₹):</label>
          <input type="number" name="price" step="0.01" required>

          <label>Product Image:</label>
          <input type="file" name="productImage" accept="image/*" required>

          <button type="submit">Add</button>
        </form>
        ${successMessage ? `<p style="color: lightgreen;">${successMessage}</p>` : ''}
      </div>
    </body>
    </html>
  `);
};

// Controller for handling product addition
exports.addProduct = (req, res) => {
  const { product_name, quantity, stock, price } = req.body;
  const image_url = req.file ? '/images/' + req.file.filename : null;

  db.query(
    'INSERT INTO products (product_name, quantity, stock, price, image_url) VALUES (?, ?, ?, ?, ?)',
    [product_name, quantity, stock, price, image_url],
    (err) => {
      if (err) return res.send('Error adding product');
      res.redirect('/admin/add-product?success=Product added successfully');
    }
  );
};

// --- 2. DELETE PRODUCT ---
exports.deleteProductForm = (req, res) => {
  const successMessage = req.query.success || '';
  db.query('SELECT product_id, product_name FROM products', (err, results) => {
    if (err) return res.send('Error fetching products');
    const options = results.map(p => `<option value="${p.product_id}">${p.product_name}</option>`).join('');
    
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Delete Product</title>
        <style>
          body {
            background: url('/images/sms2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            margin: 0;
            padding: 0;
          }
          h2 {
            text-align: center;
            margin-top: 30px;
          }
          .back-button {
            position: absolute;
            top: 20px;
            right: 30px;
            background-color: red;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
          }
          .back-button:hover {
            background-color: darkred;
          }
          .container {
            width: 400px;
            margin: 100px auto;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.4);
          }
          form {
            display: flex;
            flex-direction: column;
          }
          label, select {
            margin-bottom: 10px;
          }
          button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #1a73e8;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
          }
          button[type="submit"]:hover {
            background-color: #135abe;
          }
          p {
            text-align: center;
            margin-top: 15px;
            color: green;
          }
        </style>
      </head>
      <body>
        <button class="back-button" onclick="location.href='/admin/manage-section'">Back</button>
        <h2>Delete Product</h2>
        <div class="container">
          <form action="/admin/delete-product" method="POST">
            <label>Select Product:</label>
            <select name="product_id">${options}</select>
            <button type="submit">Delete</button>
          </form>
          ${successMessage ? `<p>${successMessage}</p>` : ''}
        </div>
      </body>
      </html>
    `);
  });
};


exports.deleteProduct = (req, res) => {
  const { product_id } = req.body;
  db.query('DELETE FROM products WHERE product_id = ?', [product_id], (err) => {
    if (err) return res.send('Error deleting product');
    res.redirect('/admin/delete-product?success=Product deleted successfully');
  });
};


// --- 3. UPDATE STOCK AND QUANTITY ---
exports.updateStockForm = (req, res) => {
  const successMessage = req.query.success || '';
  db.query('SELECT product_id, product_name FROM products', (err, results) => {
    if (err) return res.send('Error fetching products');
    const options = results.map(p => `<option value="${p.product_id}">${p.product_name}</option>`).join('');
    
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Update Stock & Quantity</title>
        <style>
          body {
            background: url('/images/sms2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            margin: 0;
            padding: 0;
          }
          h2 {
            text-align: center;
            margin-top: 30px;
          }
          .back-button {
            position: absolute;
            top: 20px;
            right: 30px;
            background-color: red;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
          }
          .back-button:hover {
            background-color: darkred;
          }
          .container {
            width: 400px;
            margin: 100px auto;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.4);
          }
          form {
            display: flex;
            flex-direction: column;
          }
          label, select, input {
            margin-bottom: 10px;
          }
          button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #1a73e8;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
          }
          button[type="submit"]:hover {
            background-color: #135abe;
          }
          p {
            text-align: center;
            margin-top: 15px;
            color: green;
          }
        </style>
      </head>
      <body>
        <button class="back-button" onclick="location.href='/admin/manage-section'">Back</button>
        <h2>Update Stock & Quantity</h2>
        <div class="container">
          <form action="/admin/update-stock" method="POST">
            <label>Select Product:</label>
            <select name="product_id">${options}</select>
            <label>New Quantity:</label>
            <input type="number" name="quantity">
            <label>New Re-stock Level:</label>
            <input type="number" name="stock">
            <button type="submit">Update</button>
          </form>
          ${successMessage ? `<p>${successMessage}</p>` : ''}
        </div>
      </body>
      </html>
    `);
  });
};



exports.updateStock = (req, res) => {
  const { product_id, quantity, stock } = req.body;
  db.query('UPDATE products SET quantity = ?, stock = ? WHERE product_id = ?', [quantity, stock, product_id], (err) => {
    if (err) return res.send('Error updating stock');
    res.redirect('/admin/update-stock?success=Stock and quantity updated successfully');
  });
};



// --- 4. ADD EMPLOYEE ---
exports.addEmployeeForm = (req, res) => {
  const successMessage = req.query.success || '';
  db.query('SELECT * FROM branches', (err, branches) => {
    if (err) return res.send('Error fetching branches');
    const options = branches.map(b => `<option value="${b.branch_id}">${b.branch_name}</option>`).join('');

    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Add Employee</title>
        <style>
          body {
            background: url('/images/sms2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            margin: 0;
            padding: 0;
          }
          h2 {
            text-align: center;
            margin-top: 30px;
          }
          .back-button {
            position: absolute;
            top: 20px;
            right: 30px;
            background-color: red;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
          }
          .back-button:hover {
            background-color: darkred;
          }
          .container {
            width: 400px;
            margin: 100px auto;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.4);
          }
          form {
            display: flex;
            flex-direction: column;
          }
          label, select, input {
            margin-bottom: 10px;
          }
          button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #1a73e8;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
          }
          button[type="submit"]:hover {
            background-color: #135abe;
          }
          p {
            text-align: center;
            margin-top: 15px;
            color: green;
          }
        </style>
      </head>
      <body>
        <button class="back-button" onclick="location.href='/admin/manage-section'">Back</button>
        <h2>Add Employee</h2>
        <div class="container">
          <form action="/admin/add-employee" method="POST">
            <label>Employee Name:</label>
            <input type="text" name="employee_name" required>
            <label>Branch:</label>
            <select name="branch_id" required>${options}</select>
            <button type="submit">Add</button>
          </form>
          ${successMessage ? `<p>${successMessage}</p>` : ''}
        </div>
      </body>
      </html>
    `);
  });
};



exports.addEmployee = (req, res) => {
  const { employee_name, branch_id } = req.body;
  db.query('INSERT INTO employees (employee_name, branch_id) VALUES (?, ?)', [employee_name, branch_id], (err) => {
    if (err) return res.send('Error adding employee');
    res.redirect('/admin/add-employee?success=Employee added successfully');
  });
};


// --- 5. DELETE EMPLOYEE ---
exports.deleteEmployeeForm = (req, res) => {
  const successMessage = req.query.success || '';
  db.query('SELECT employee_id, employee_name FROM employees', (err, results) => {
    if (err) return res.send('Error fetching employees');
    const options = results.map(emp => `<option value="${emp.employee_id}">${emp.employee_name}</option>`).join('');

    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Delete Employee</title>
        <style>
          body {
            background: url('/images/sms2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            margin: 0;
            padding: 0;
          }
          h2 {
            text-align: center;
            margin-top: 30px;
          }
          .back-button {
            position: absolute;
            top: 20px;
            right: 30px;
            background-color: red;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
          }
          .back-button:hover {
            background-color: darkred;
          }
          .container {
            width: 400px;
            margin: 100px auto;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.4);
          }
          form {
            display: flex;
            flex-direction: column;
          }
          label, select {
            margin-bottom: 10px;
          }
          button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #1a73e8;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
          }
          button[type="submit"]:hover {
            background-color: #135abe;
          }
          p {
            text-align: center;
            margin-top: 15px;
            color: green;
          }
        </style>
      </head>
      <body>
        <button class="back-button" onclick="location.href='/admin/manage-section'">Back</button>
        <h2>Delete Employee</h2>
        <div class="container">
          <form action="/admin/delete-employee" method="POST">
            <label>Select Employee:</label>
            <select name="employee_id" required>${options}</select>
            <button type="submit">Delete</button>
          </form>
          ${successMessage ? `<p>${successMessage}</p>` : ''}
        </div>
      </body>
      </html>
    `);
  });
};



exports.deleteEmployee = (req, res) => {
  const { employee_id } = req.body;
  db.query('DELETE FROM employees WHERE employee_id = ?', [employee_id], (err) => {
    if (err) return res.send('Error deleting employee');
    res.redirect('/admin/delete-employee?success=Employee deleted successfully');
  });
};
