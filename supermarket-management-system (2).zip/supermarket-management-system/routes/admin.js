// routes/admin.js
const express = require('express');
const path = require('path');
const router = express.Router();
const adminController = require('../controllers/adminController');

// Multer setup for file upload
const multer = require('multer');
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../public/images'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// GET login page
router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../views/login.html'));
});

// POST login form submission
router.post('/login', adminController.login);

// Dashboard route
router.get('/dashboard', adminController.dashboard);

// View Section Route
router.get('/view-section', (req, res) => {
  res.sendFile(path.join(__dirname, '../views/viewSection.html'));
});

// Manage Section Route
router.get('/manage-section', (req, res) => {
  res.sendFile(path.join(__dirname, '../views/manageSection.html'));
});

// View data routes (used in view section)
router.get('/view-branch', adminController.viewBranch);
router.get('/view-employee', adminController.viewEmployee);
router.get('/view-admin', adminController.viewAdmin);
router.get('/view-customers', adminController.viewCustomers);
router.get('/view-products', adminController.viewProducts);

// Add product routes
router.get('/add-product', adminController.addProductForm);
router.post('/add-product', upload.single('productImage'), adminController.addProduct);

// Delete & update product
router.get('/delete-product', adminController.deleteProductForm);
router.post('/delete-product', adminController.deleteProduct);

router.get('/update-stock', adminController.updateStockForm);
router.post('/update-stock', adminController.updateStock);

// Employee routes
router.get('/add-employee', adminController.addEmployeeForm);
router.post('/add-employee', adminController.addEmployee);

router.get('/delete-employee', adminController.deleteEmployeeForm);
router.post('/delete-employee', adminController.deleteEmployee);

module.exports = router;
