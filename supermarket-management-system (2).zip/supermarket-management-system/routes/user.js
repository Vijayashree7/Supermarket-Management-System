const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

router.get('/products', userController.getProducts);
router.post('/calculate-total', userController.calculateTotal);
router.post('/purchase', userController.purchaseProducts);

module.exports = router;
