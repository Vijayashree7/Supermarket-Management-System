console.log("Supermarket JS Loaded");

// Wait for DOM to load
document.addEventListener("DOMContentLoaded", () => {
  const purchaseBtn = document.getElementById("purchaseBtn");

  if (purchaseBtn) {
    purchaseBtn.addEventListener("click", function () {
      const selectedProducts = Array.from(document.getElementById("products").selectedOptions)
        .map(option => option.value);

      console.log("Selected Products:", selectedProducts);

      // You can now send `selectedProducts` to the backend using fetch/AJAX if needed
    });
  }
});
