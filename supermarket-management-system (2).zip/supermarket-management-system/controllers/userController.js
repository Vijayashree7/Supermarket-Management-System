const db = require('../db');
const { sendLowStockAlert } = require('../utils/mailer'); // 👈 Added mailer

// Fetch all products (including price)
exports.getProducts = (req, res) => {
  const query = 'SELECT product_id, product_name, price FROM products';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching products:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
};

// Calculate total price
exports.calculateTotal = (req, res) => {
  const productQuantities = req.body;

  const productIds = Object.keys(productQuantities);
  if (productIds.length === 0) return res.status(400).send("No products selected");

  const placeholders = productIds.map(() => '?').join(',');
  const sql = `SELECT product_id, price FROM products WHERE product_id IN (${placeholders})`;

  db.query(sql, productIds, (err, results) => {
    if (err) return res.status(500).send('Error calculating total');

    let total = 0;
    results.forEach(product => {
      const qty = parseInt(productQuantities[product.product_id]);
      total += product.price * qty;
    });

    res.json({ total });
  });
};

// Confirm Purchase
exports.purchaseProducts = (req, res) => {
  const customer_name = req.body.customer_name;
  const productQuantities = req.body.products;

  const date = new Date();

  db.query(
    'INSERT INTO customers (customer_name, purchase_date) VALUES (?, ?)',
    [customer_name, date],
    (err, result) => {
      if (err) return res.status(500).send('Error saving purchase');

      const customer_id = result.insertId;

      const updates = Object.entries(productQuantities).map(([pid, qty]) => {
        return new Promise((resolve, reject) => {
          // 1. Reduce quantity
          db.query(
            'UPDATE products SET quantity = quantity - ? WHERE product_id = ?',
            [qty, pid],
            (err) => {
              if (err) return reject(err);

              // 2. Insert into purchase table
              db.query(
                'INSERT INTO purchases (customer_id, product_id, quantity) VALUES (?, ?, ?)',
                [customer_id, pid, qty],
                (err) => {
                  if (err) return reject(err);

                  // 3. Check for low stock
                  db.query(
                    'SELECT product_name, quantity, stock FROM products WHERE product_id = ?',
                    [pid],
                    (err, results) => {
                      if (err) return reject(err);

                      const product = results[0];
                      if (product.quantity < product.stock) {
                        sendLowStockAlert(product.product_name, product.quantity);
                      }

                      resolve();
                    }
                  );
                }
              );
            }
          );
        });
      });

      Promise.all(updates)
        .then(() => res.send('Products purchased'))
        .catch(() => res.status(500).send('Error updating stock or saving purchase'));
    }
  );
};


// userController.js - getProducts
exports.getProducts = (req, res) => {
  const query = 'SELECT product_id, product_name, price, image_url FROM products';  // add image_url
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching products:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
};
