const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.ALERT_EMAIL,        // Your sender email
    pass: process.env.ALERT_EMAIL_PASS    // App password (not your Gmail password)
  }
});

function sendLowStockAlert(productName, remainingQty) {
  const mailOptions = {
    from: process.env.ALERT_EMAIL,
    to: process.env.ALERT_RECEIVER,  // Recipient email (could be same or different)
    subject: `Low Stock Alert: ${productName}`,
    text: `The product "${productName}" is low on stock. Remaining quantity: ${remainingQty}`
  };

  transporter.sendMail(mailOptions, (err, info) => {
    if (err) console.error('Error sending mail:', err);
    else console.log('Low stock alert sent:', info.response);
  });
}

module.exports = { sendLowStockAlert };
